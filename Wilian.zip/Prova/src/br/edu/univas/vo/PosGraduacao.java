package br.edu.univas.vo;

public class PosGraduacao extends Aluno {

}
