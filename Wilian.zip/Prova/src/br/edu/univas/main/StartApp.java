package br.edu.univas.main;
import java.util.ArrayList;
import java.util.Scanner;

import br.edu.univas.vo.*;


public class StartApp {
	
	public static void main(String[] args) {
		
		
			printMenu();
			
			cadastraAlunos();
		
		
		
		
		
		
		
	}
	public static void cadastraAlunos() {
		Scanner sc = new Scanner(System.in);
		Aluno alunos = new Aluno();
        System.out.println("Cadastro de Alunos");
        System.out.println("Digite o seu nome");
        alunos.setNome(sc.nextLine());
        System.out.println("Digite o seu cpf");
        alunos.setCpf(sc.nextInt());
        System.out.println("Digite o seu email");
        alunos.setEmail(sc.nextLine());
          
        
          
        }
	
	public static void listaAlunos() {
	
        
	}
	public static void printMenu() {
		
		System.out.println("1. Cadastro de aluno");
		System.out.println("2. Listar alunos P�s");
		System.out.println("3. Listar alunos Mestrado");
		System.out.println("4. Sair");
		
	}

	
	
	public static int readInteger(Scanner sc) {
        int result = sc.nextInt();
        sc.nextLine();
        return result;
    }
	public static double readDouble(Scanner sc) {
        double result = sc.nextDouble();
        sc.nextLine();
        return result;
    }
}
